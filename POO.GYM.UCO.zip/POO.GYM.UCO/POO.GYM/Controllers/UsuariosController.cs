using Microsoft.AspNetCore.Mvc;
using POO.GYM.Models;

namespace POO.GYM.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UsuariosController : ControllerBase
    {
        [HttpGet]
        public IActionResult ObtenerUsuarios()
        {
            List<Usuario> usuarios = new List<Usuario>()
            {
                new Usuario
                {
                    IdUsuario = 1,
                    Nombre = "Tomás",
                    Objetivo = "Hipertrofia"
                },

                new Usuario
                {
                    IdUsuario = 2,
                    Nombre = "Carlos",
                    Objetivo = "Pérdida de peso"
                }
            };

            return Ok(usuarios);
        }
    }
}