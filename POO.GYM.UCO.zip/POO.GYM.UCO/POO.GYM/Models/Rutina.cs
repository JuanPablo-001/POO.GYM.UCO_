﻿namespace POO.GYM.Models
{
    public class Rutina
    {
        public int IdRutina { get; set; }        
        public string Nombre { get; set; }
        public string Objetivo { get; set; }
        public string Descripcion { get; set; }
        public int Duracion { get; set; }
     

        public List<Ejercicio> Ejercicios { get; set; } 

        public Rutina()
        {
            Ejercicios = new List<Ejercicio>();
        }
    }
}
