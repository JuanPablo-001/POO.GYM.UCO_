﻿namespace POO.GYM.Models { 

    public abstract class Entrenador : Persona
    {
        public string Certificados { get; set; }    
        public int Experiencia { get; set; }
        public string Estado { get; set; }
        public double Calificacion { get; set; }
        public string disponibilidad { get; set; }
        public string Especialidad { get; set; }
        
  

            // Relación con usuarios
            public List<Usuario> Usuarios { get; set; } = new List<Usuario>();
        
    }
}

